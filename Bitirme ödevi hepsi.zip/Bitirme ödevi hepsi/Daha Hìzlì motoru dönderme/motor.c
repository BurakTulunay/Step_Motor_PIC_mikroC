void main() {
int i,k;
trisc=0;
portc=0;

for(i=0;i<24;i++) {
portc=12;
delay_ms(300);
portc=6;
delay_ms(300);
portc=3;
delay_ms(300);
portc=9;
delay_ms(300);
}
}

/*

Bu Program MikroC nin eski versiyonlar�nda, di�er programa g�re motoru daha h�zl� d�nderiyor.
ama v5.6 versiyonunda her iki programda da motor ayn� h�zda d�nd�.
(di�er program i� i�e ge�mi� iki for d�ng�s�nden meydana geliyor.)

di�er program:

for(k=0;k<6;k++) {
for(i=0;i<4;i++) {
delay_ms(3);
portc=adim[i]; 

*/