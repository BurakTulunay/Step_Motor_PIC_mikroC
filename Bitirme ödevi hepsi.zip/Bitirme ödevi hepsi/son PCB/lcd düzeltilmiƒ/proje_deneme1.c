
#define sat1 portb.b4
#define sat2 portb.b5
#define sat3 portb.b6
#define sat4 portb.b7

#define sut1 portc.b4
#define sut2 portc.b5
#define sut3 portc.b6
#define sut4 portc.b7

sbit LCD_RS at RA5_bit;
sbit LCD_EN at RA4_bit;
sbit LCD_D4 at RA3_bit;
sbit LCD_D5 at RA2_bit;
sbit LCD_D6 at RA1_bit;
sbit LCD_D7 at RA0_bit;

sbit LCD_RS_Direction at TRISA5_bit;
sbit LCD_EN_Direction at TRISA4_bit;
sbit LCD_D4_Direction at TRISA3_bit;
sbit LCD_D5_Direction at TRISA2_bit;
sbit LCD_D6_Direction at TRISA1_bit;
sbit LCD_D7_Direction at TRISA0_bit;

void interrupt()        // duraklat
{
portc=0;
while(portb.b1);      //devam et tu�udur.
intcon.intf=0;
}

unsigned int k1,stp;
void bekle1() {
if(k1==0) {
delay_ms(100);          //x3ms
}
if(k1==1) {
delay_ms(50);            //x1ms
}
}
void bekle2() {
if(k1==0) {
delay_ms(50);         //x1ms
}
if(k1==1) {
delay_ms(100);             //x3ms
}
}


void reset() {            // program yazacam reset ekle.motor ba�a d�ns�n

}


void main() {

unsigned char adim1[4]={3,6,12,9},flg;
unsigned char adim2[4]={12,6,3,9},j;

unsigned char r0,r1,r2,r3,r4,r5,r6,r7,r8,r9,i,tus,x=0;
unsigned int rr0=0,rr1=0,rr2=0,rr3=0,rr4=0,rr5=0,rr6=0,rr7=0,rr8=0,rr9=0;
unsigned int rkm0,rkm1,rkm2,rkm3,rkm4,rkm5,rkm6,rkm7,rkm8,rkm9;
unsigned int m1,m2,m3,m4;
unsigned char s1,s2,s3,s4;
unsigned int katsayi=1,toplam,sonuc;            //  ,k[7]

dur:     // ba�ka yere koyunca hata veriyor.
x=0;rr0=0;rr1=0;rr2=0;rr3=0;rr4=0;rr5=0;rr6=0;rr7=0;rr8=0;rr9=0;katsayi=1;


trisa=0;    //trisd=0b00000000;
porta=0;  //portd=0;
trisb=0b00000011;   //�IKI�
trisc=0b11110000;
portb=0;
portc=0;
adcon1=7;
cmcon=7;
option_reg.intedg=0;         //1 olsayd� butondan elini �ekince aktif olurdu.
intcon.gie=1;                //t�m kesmelere izin verilir(0 iken kesmeler �al��maz)
intcon.inte=1;               //RB0/INT kesmesi aktif olur

lcd_init();
lcd_cmd(_lcd_clear);
lcd_cmd(_lcd_cursor_off);
lcd_out(1,1,"ADIM SAYISI:");   // en az 16 ad�m girilecek. ve 4 �n katlar� �eklinde.
lcd_out(2,1,"");

for(;;) {
delay_ms(10);        // ger�ek zamanl� �al��mas� i�in 1ms lik ge�ikme koydum.
sat1=1;              // sat�rlar s�rayla 1 yap�larak tarama i�lemi ba�lat�l�yor.
if(sut1) {           // sut1==1 ile ayn� i�i yap�yor.
delay_ms(20);
tus=0;
r0=tus+48;                         //say�y� ASCII olarak yazd�rmak i�in.
lcd_chr_cp(r0);
x++;
katsayi=1;
if(x>1) {
for(i=1;i<x;i++) {
katsayi*=10;
}
}
/*else {                // bu kal�b� kald�r�p tekrar dene.
katsayi=1;
}    */
rkm0=tus*katsayi;
rr0=rr0+rkm0;
while(sut1==1);      // tu� bas�l� kald��� s�rece bu sat�rda bekler.
}

if(sut2) {           // sut1==1 ile ayn� i�i yap�yor.
delay_ms(20);
tus=1;
r1=tus+48;
lcd_chr_cp(r1);
x++;
katsayi=1;
if(x>1) {
for(i=1;i<x;i++) {
katsayi*=10;
}
}
/*else {
katsayi=1;
}   */
rkm1=tus*katsayi;
rr1=rr1+rkm1;
while(sut2==1);
}

if(sut3) {
delay_ms(20);        // bu ge�ikmeler tu� parazitlerini engellemek i�in.
tus=2;
r2=tus+48;
lcd_chr_cp(r2);
x++;
katsayi=1;
if(x>1) {
for(i=1;i<x;i++) {
katsayi*=10;
}
}
/*else {
katsayi=1;
}     */
rkm2=tus*katsayi;
rr2=rr2+rkm2;
while(sut3==1);
}

if(sut4) {
delay_ms(20);
tus=3;
r3=tus+48;
lcd_chr_cp(r3);
x++;
katsayi=1;
if(x>1) {
for(i=1;i<x;i++) {
katsayi*=10;
}
}
/*else {
katsayi=1;
}   */
rkm3=tus*katsayi;
rr3=rr3+rkm3;
while(sut4==1);
}

sat1=0;
delay_ms(1);
sat2=1;
if(sut1) {
delay_ms(20);
tus=4;
r4=tus+48;
lcd_chr_cp(r4);
x++;
katsayi=1;
if(x>1) {
for(i=1;i<x;i++) {
katsayi*=10;
}
}
/*else {
katsayi=1;
}     */
rkm4=tus*katsayi;
rr4=rr4+rkm4;
while(sut1==1);
}

if(sut2) {
delay_ms(20);
tus=5;
r5=tus+48;
lcd_chr_cp(r5);
x++;
katsayi=1;
if(x>1) {
for(i=1;i<x;i++) {
katsayi*=10;
}
}
/*else {
katsayi=1;
}       */
rkm5=tus*katsayi;
rr5=rr5+rkm5;
while(sut2==1);
}

if(sut3) {
delay_ms(20);
tus=6;
r6=tus+48;
lcd_chr_cp(r6);
x++;
katsayi=1;
if(x>1) {
for(i=1;i<x;i++) {
katsayi*=10;
}
}
/*else {
katsayi=1;
}    */
rkm6=tus*katsayi;
rr6=rr6+rkm6;
while(sut3==1);
}

if(sut4) {
delay_ms(20);
tus=7;
r7=tus+48;
lcd_chr_cp(r7);
x++;
katsayi=1;
if(x>1) {
for(i=1;i<x;i++) {
katsayi*=10;
}
}
/*else {
katsayi=1;
}    */
rkm7=tus*katsayi;
rr7=rr7+rkm7;
while(sut4==1);
}

sat2=0;
delay_ms(1);
sat3=1;
if(sut1) {
delay_ms(20);
tus=8;
r8=tus+48;
lcd_chr_cp(r8);
x++;
katsayi=1;
if(x>1) {
for(i=1;i<x;i++) {
katsayi*=10;
}
}
/*else {
katsayi=1;
}   */
rkm8=tus*katsayi;
rr8=rr8+rkm8;
while(sut1==1);
}

if(sut2) {
delay_ms(20);
tus=9;
r9=tus+48;
lcd_chr_cp(r9);
x++;
katsayi=1;
if(x>1) {
for(i=1;i<x;i++) {
katsayi*=10;
}
}
/*else {
katsayi=1;
}   */
rkm9=tus*katsayi;
rr9=rr9+rkm9;
while(sut2==1);
}

if(sut3) {
delay_ms(50);
flg=0;                     // bayrak 0 yap�ld�.
break;                     // tarama d�g�s�nden ��k.
}

if(sut4) {
delay_ms(50);
flg=1;                     // bayrak 1 yap�ld�.
break;                     // tarama d�ng�s�nden ��k.
}

sat3=0;
delay_ms(1);

sat4=1;
if(sut3) {            // bu k�s�mda e�er girilen say� yanl�� ise reset at�l�r.
goto dur;             // reset1
}
delay_ms(1);
sat4=0;
}

toplam=rr0+rr1+rr2+rr3+rr4+rr5+rr6+rr7+rr8+rr9;

s1=toplam/10000;
m1=toplam%10000;
s2=m1/1000;
m2=m1%1000;
s3=m2/100;
m3=m2%100;
s4=m3/10;
m4=m3%10;

if(x==1) {
sonuc=toplam;
}
if(x==2) {
sonuc=(m4*10)+s4;
}
if(x==3) {
sonuc=(m4*100)+(s4*10)+s3;
}
if(x==4) {
sonuc=(m4*1000)+(s4*100)+(s3*10)+s2;
}
if(x==5) {
sonuc=(m4*10000)+(s4*1000)+(s3*100)+(s2*10)+s1;
}

/*inttostr(sonuc,k);       // girilen say�y� yazd�r. programdan ��kard�m.
lcd_out(2,1,k);
  */

sat3=0;                   // reset tu�u kar��mas�n diye. ��nk� keypad d�ng�s�nden ��k�nca sat3 �ok k�sa bi s�re lojik 1 de kal�yor.
sat4=1;                   // reset1 ve reset2 nin �al��mas� i�in 1 yap�lmal�d�r.��nk� d�ng�den ��k�nca lajik 0 d�r.

stp=sonuc/4;

if(flg==0) {                   // bayrak s�f�rsa sa�a d�nder.
for(k1=0;k1<2;k1++) {
for(i=0;i<4;i++) {
bekle1();
portc=adim1[i];
}
}
for(k1=0;k1<stp-4;k1++) {        //  2 h�zlanmada 2 de yava�lamada kullan�ld��� i�in stp-4
for(i=0;i<4;i++) {
delay_ms(5);                      //3ms
portc=adim1[i];
//sat4=1;                        // portc.b5 in durumu i�in 1 yap�ld�.
if(portc.b4==1) {               // reset1
goto dur;
}
}
}
for(k1=0;k1<2;k1++) {
for(i=0;i<4;i++) {
bekle2();
portc=adim1[i];
}
}
}

if(flg==1) {                    // bayrak 1 ise sola d�nder.
for(k1=0;k1<2;k1++) {
for(j=0;j<4;j++) {             // j, int olmak zorunda.
bekle1();
portc=adim2[j];
}
}
for(k1=0;k1<stp-4;k1++) {
for(j=0;j<4;j++) {
delay_ms(5);                //3ms
portc=adim2[j];
//sat4=1;
if(portc.b4==1) {               // reset1
goto dur;
}
}
}
for(k1=0;k1<2;k1++) {
for(j=0;j<4;j++) {
bekle2();
portc=adim2[j];
}
}
}

for(;;) {                       // burada sonsuz d�ng� kesinlikle �art!
//sat4=1;
if(portc.b4==1) {               // reset1
goto dur;
}
if(portc.b5==1) {               // reset2
reset();
}
}
}