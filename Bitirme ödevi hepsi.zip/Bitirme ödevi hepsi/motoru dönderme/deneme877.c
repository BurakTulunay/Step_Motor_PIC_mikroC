unsigned int k1,stp;
void bekle1() {
if(k1==0) {
delay_ms(10);
}
if(k1==1) {
delay_ms(6);
}
}
void bekle2() {
if(k1==0) {
delay_ms(10);
}
if(k1==1) {
delay_ms(6);
}
}
void main() {
unsigned char adim1[4]={3,6,12,9};
int i,k1;
trisc=0;
portc=0;
stp=480;

for(k1=0;k1<2;k1++) {
for(i=0;i<4;i++) {
bekle1();
portc=adim1[i];
}
}

for(k1=0;k1<stp-4;k1++) {    //  2 h�zlanmada 2 de yava�lamada kullan�ld��� i�in stp-4
for(i=0;i<4;i++) {
delay_ms(3);                 // proteusta tek tek denedim 3ms de ad�m ka��rm�yor.
portc=adim1[i];
}
}

for(k1=0;k1<2;k1++) {
for(i=0;i<4;i++) {
bekle2();
portc=adim1[i];
}
}
}